Adresar SETUP obsahuje instalaciu ARITY32 prologu, ktora funguje na Windows 10.
(Pravdepodobne aj na skorsich).
Po nainstalovani do arity32 do c:\arity32, je potrebne do adresara c:\arity32\bin
nakopirovat obsah foldra sapfo_ari_files\original.

Potom je mozne spustit subor c:\ARITY32\bin\API32.EXE.
Trochu tazkopadne sa s tym robi, treba prist na to ako sa da dostat do menu aplikacie.
Alt+F by malo fungovat - a zobrazit menu File.
Samotnu aplikaciu je mozne spustit zadanim nasledovnych prikazov :
[refresh].
fresh. (Nasledne Enter)
[constant].
main.

Adresar sapfo_ari_files\readable-utf8 obsahuje zdrojaky citatelne v utf-8.
Ak sa otvoria napriklad v notepade, obsahuju korektne znaky miesto klikihakov v diakritike.

Do vstupnych obrazoviek sa mi podarilo diakritiku dostat len tak, ze som si do uvodnej
obrazovky aplikacie vlozil riadok, ktory obsahuje vsetky znaky s diakritikou.
A napr�klad slovo Diev�ina, som zad�val tak, �e som nap�sal Diev, potom i�iel do 
uvodnej obrazovky, klikol na znak za c - co bolo �, skop�roval ho do clipboardu
a pastol som ho do input pol��ka aplik�cie. 
